const taskInput = document.getElementById('input-box');
const taskList = document.getElementById('taskList'); // Corrected from createElement("taskList");

const tasks = JSON.parse(localStorage.getItem('tasks')) || [];

function addTask() {
    const taskText = taskInput.value;
    if (taskText === '') return;
    const task = { Text: taskText }; // Corrected property name
    tasks.push(task);
    localStorage.setItem('tasks', JSON.stringify(tasks));
    taskInput.value = '';
    displayTasks(); // Corrected function name
}

function deleteTask(index) {
    tasks.splice(index, 1);
    localStorage.setItem('tasks', JSON.stringify(tasks));
    displayTasks(); // Corrected function name
}

function editTask(index) {
    const newTaskText = prompt('Edit the Task', tasks[index].Text); // Corrected property name
    if (newTaskText !== null) {
        tasks[index].Text = newTaskText; // Corrected property name
        localStorage.setItem('tasks', JSON.stringify(tasks));
        displayTasks(); // Corrected function name
    }
}

function displayTasks() { // Corrected function name
    taskList.innerHTML = '';
    tasks.forEach((task, index) => {
        const li = document.createElement('li');
        li.innerHTML = `
            <span>${task.Text}</span>
            <hr>
            <button class="edit-button" onclick="editTask(${index})">Edit</button>
            <button class="delete-button" onclick="deleteTask(${index})">Delete</button>
        `;
        taskList.appendChild(li);
    });
}

// Initial display when the page loads
displayTasks();
